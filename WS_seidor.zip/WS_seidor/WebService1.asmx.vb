﻿Imports System.ComponentModel
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

' Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente.
' <System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class WebService1
    Inherits System.Web.Services.WebService


    <WebMethod()>
    Public Function clienteGuardar(Nombre As String, dni As String, fecha_nacimiento As Date, saldo As Double) As String
        Dim puntos As Integer = 0
        Dim fechaActual As Date = Date.Now
        Dim fechaNac As Date = fecha_nacimiento

        Dim days As Long = DateDiff("yyyy", fechaNac, fechaActual)

        If days <= 40 Then
            puntos = 1000
        Else
            puntos = 100

        End If

        Dim con = New SqlConnection("Data Source=DESKTOP-V4RLIQG;Initial Catalog=seidor;Integrated Security=true;")
        con.Open()
        Dim com = New SqlCommand()
        com.Connection = con
        com.CommandType = CommandType.StoredProcedure
        com.CommandText = "spInsertUser"

        com.Parameters.Add("@nombre", SqlDbType.NVarChar).Value = Nombre
        com.Parameters.Add("@dni", SqlDbType.NVarChar).Value = dni
        com.Parameters.Add("@fecha_nacimiento", SqlDbType.NVarChar).Value = fecha_nacimiento

        com.ExecuteNonQuery()

        Dim compuntos = New SqlCommand With {
            .Connection = con,
            .CommandType = CommandType.StoredProcedure,
            .CommandText = "spInsertPunto"
        }

        compuntos.Parameters.Add("@puntos", SqlDbType.NVarChar).Value = puntos
        compuntos.Parameters.Add("@dni", SqlDbType.NVarChar).Value = dni

        compuntos.ExecuteNonQuery()

        Dim comsaldos = New SqlCommand With {
            .Connection = con,
            .CommandType = CommandType.StoredProcedure,
            .CommandText = "spInsertSaldo"
        }

        comsaldos.Parameters.Add("@saldo", SqlDbType.NVarChar).Value = saldo
        comsaldos.Parameters.Add("@dni", SqlDbType.NVarChar).Value = dni

        comsaldos.ExecuteNonQuery()

        Return "Registrado con exito"

    End Function

    <WebMethod()>
    Public Function clienteAbonar(dni As String, monto As Double) As String
        Dim puntos As Integer = 0

        If monto >= 40 Then
            puntos = 200
        Else
            puntos = 50

        End If

        Dim con = New SqlConnection("Data Source=DESKTOP-V4RLIQG;Initial Catalog=seidor;Integrated Security=true;")
        con.Open()

        Dim compuntos = New SqlCommand With {
            .Connection = con,
            .CommandType = CommandType.StoredProcedure,
            .CommandText = "spInsertPunto"
        }

        compuntos.Parameters.Add("@puntos", SqlDbType.NVarChar).Value = puntos
        compuntos.Parameters.Add("@dni", SqlDbType.NVarChar).Value = dni

        compuntos.ExecuteNonQuery()

        Dim comsaldos = New SqlCommand With {
            .Connection = con,
            .CommandType = CommandType.StoredProcedure,
            .CommandText = "spInsertSaldo"
        }

        comsaldos.Parameters.Add("@saldo", SqlDbType.NVarChar).Value = monto
        comsaldos.Parameters.Add("@dni", SqlDbType.NVarChar).Value = dni

        comsaldos.ExecuteNonQuery()

        Return "Agregado con exito"

    End Function

    <WebMethod()>
    Public Function Reporte() As String

        Dim strQuery As String
        Dim lista As String
        lista = "datos"

        strQuery = "SELECT nombre, dni, CONVERT(VARCHAR(24), fecha_nacimiento, 113), CONVERT(VARCHAR(24), (select sum(clientepuntos.puntos) from clientepuntos where clientepuntos.dni=clientes.dni), 113) as punto,  CONVERT(VARCHAR(24), (select sum(saldo) from clientesaldo where clientesaldo.dni=clientes.dni), 113) as saldo  FROM clientes"

        Dim sqlCon = New SqlConnection("Data Source=DESKTOP-V4RLIQG;Initial Catalog=seidor;Integrated Security=true;")

        Using (sqlCon)

            Dim sqlComm As SqlCommand = New SqlCommand(strQuery, sqlCon)

            sqlCon.Open()

            Dim sqlReader As SqlDataReader = sqlComm.ExecuteReader()

            If sqlReader.HasRows Then

                While (sqlReader.Read())

                    Console.WriteLine(sqlReader.GetString(1), "{0}", lista)



                End While


            End If

            sqlReader.Close()

            Return lista

        End Using

    End Function

End Class